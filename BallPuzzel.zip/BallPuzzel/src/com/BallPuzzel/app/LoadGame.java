package com.BallPuzzel.app;

import java.util.Random;

public class LoadGame extends Puzzle {

	public void fillContainer() 
    {
        Random random = new Random();
        int[] colorAmounts = new int[ballColors.length];
        int currentColor;
        int currentContainer;
        boolean colorAdded;
        boolean ContainerFilled;
        for (int i = 0; i < colorAmounts.length; i++) 
        {
            colorAmounts[i] = ball_container[0].length;
        }
        do
        {
        	ContainerFilled = true;
            currentColor = random.nextInt(colorAmounts.length);
            if (colorAmounts[currentColor] > 0) 
            {
                colorAdded = false;
                while (!colorAdded) 
                {
                    currentContainer= random.nextInt(ball_container.length - 1);
                    for (int i = 0; i < ball_container[currentContainer].length; i++) 
                    {
                        if (ball_container[currentContainer][i] == null) 
                        {
                            ball_container[currentContainer][i] = ballColors[currentColor];
                            colorAmounts[currentColor]--;
                            colorAdded = true;
                            break;
                        }
                    }
                }
            }
            for (int colorAmount : colorAmounts) 
            {
                if (colorAmount > 0) 
                {
                	ContainerFilled = false;
                    break;
                }
            }
        }
        while (!ContainerFilled);
    }

}
