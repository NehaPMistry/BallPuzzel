package com.BallPuzzel.app;

public class MovesNode {
	int to;
	int toSection;
	int from;
	int fromSection;
	MovesNode next;
	MovesNode prev;
	
	public MovesNode(int to, int toSection, int from, int fromSection)
	{
		super();
		this.to = to;
		this.from = from;
		this.toSection = toSection;
		this.fromSection = fromSection;
		this.next = null;
		this.prev = null;
	}
	
	public static MovesNode addMove(MovesNode Latest_Move, int to, int toSection, int from, int fromSection)
	{
		MovesNode new_Move = new MovesNode(to, toSection, from, fromSection);
		
		if(Latest_Move != null)
		{
	        Latest_Move.next = new_Move;
	        new_Move.prev = Latest_Move;
		}
        Latest_Move = new_Move;
		return Latest_Move;
	}
}
