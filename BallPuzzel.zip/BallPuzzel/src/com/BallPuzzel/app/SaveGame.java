package com.BallPuzzel.app;

public class SaveGame {

	public SaveGame() {
		
		// TODO Auto-generated constructor stub
		
		// Implementation is still pending ....
	}

}
