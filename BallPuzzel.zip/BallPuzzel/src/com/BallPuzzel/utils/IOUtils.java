package com.BallPuzzel.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import com.BallPuzzel.app.*;
import static com.BallPuzzel.app.LoadGame.*;

public interface IOUtils 
{
	// add a static method for serialization.
	static void SaveGame(String[][] bottles, String fileName) throws IOException {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName))) {
			out.writeObject(bottles);
		}
	}

	// add a static method for de-serialization.
	@SuppressWarnings("unchecked")
	static String [][] RestoreGame(String fileName) throws IOException, ClassNotFoundException {
		
		File f1 = new File(fileName);	// file validation
		String[][] bottles;
		if (f1.isFile() && f1.canRead()) 
		{
			try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f1))) 
			{
				bottles = (String[][])in.readObject();// de serial
				return bottles;
			}
		}
		System.out.println("Invalid file name or file doesn't exist !!!!!!!!!!!!!!!!!");
		return null;
	}

}
