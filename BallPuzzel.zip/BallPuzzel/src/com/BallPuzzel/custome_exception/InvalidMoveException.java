package com.BallPuzzel.custome_exception;

@SuppressWarnings("serial")
public class InvalidMoveException extends Exception{

	public InvalidMoveException(String msg) {
		super(msg);
	}

}
